"""
CrysX-NN.

A pure python neural network library from Phys Whiz (https://www.bragitoff.com)
"""

__version__ = "0.1.0"
__author__ = 'Manas Sharma'
__credits__ = 'Phys Whiz (bragitoff.com)'